<?php

function pmwi_pmxi_delete_post( $ids, $import ){
//    if ( $import->options['custom_type'] == 'product' && ! empty($ids)){
//        foreach ($ids as $pid){
//            $post_to_delete = get_post($pid);
//            if ( $post_to_delete and $post_to_delete->post_type == 'product_variation' && ! empty($post_to_delete->post_parent))
//            {
//                wp_delete_post($pid);
//                $product = new WC_Product_Variable($post_to_delete->post_parent);
//                WC_Product_Variable::sync($product);
//            }
//        }
//    }
}